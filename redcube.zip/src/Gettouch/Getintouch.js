import React from 'react';


function Getintouch() {
  return (
    <>
    <div className="gettouch">
        <div className="container">
            <div className="row">
                <div className="col-lg-6">
                    <div className="gettouchBox"> 
                        <h3>So, you have a project. </h3>
                        <h3>We can take it to another level. </h3>
                        <h4>Schedule a meeting with us.</h4>
                        <a href="#link" className="btn1">Get in Touch</a>
                    </div>
                </div>
                <div className="col-lg-6"></div>
            </div>
        </div>        
    </div>
    </>
    
    
  );
}

export default Getintouch;
