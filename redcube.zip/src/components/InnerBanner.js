import React from 'react';
import innban from '../assets/images/inner-banner.jpg';


const InnerBanner = () => {
  return (
    <>

    <div className="bannermn">
        <img src={innban} alt="Banner" />
    </div>      
    </>
  );
};

export default InnerBanner;